<?php
session_start();

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// DB connection
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "ideaspark_db";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Handle AJAX requests
if (isset($_POST['action'])) {
    $idea_id = intval($_POST['idea_id']);
    $user_id = $_SESSION['user_id'];

    if ($_POST['action'] === 'pin') {
        // Toggle pin
        $current = $conn->query("SELECT pinned FROM ideas WHERE id=$idea_id AND user_id=$user_id")->fetch_assoc();
        $newStatus = $current['pinned'] ? 0 : 1;
        $conn->query("UPDATE ideas SET pinned=$newStatus WHERE id=$idea_id AND user_id=$user_id");
        echo json_encode(['pinned' => $newStatus]);
        exit();
    }

    if ($_POST['action'] === 'delete') {
        $conn->query("DELETE FROM ideas WHERE id=$idea_id AND user_id=$user_id");
        echo json_encode(['deleted' => true]);
        exit();
    }

    if ($_POST['action'] === 'edit') {
        $title = $conn->real_escape_string($_POST['title']);
        $description = $conn->real_escape_string($_POST['description']);
        $category = $conn->real_escape_string($_POST['category']);
        $conn->query("UPDATE ideas SET title='$title', description='$description', category='$category' WHERE id=$idea_id AND user_id=$user_id");
        echo json_encode(['updated' => true]);
        exit();
    }
}

// Fetch user ideas
$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM ideas WHERE user_id='$user_id' ORDER BY date_created DESC");

$ideas = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $ideas[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Ideas | IdeaSpark</title>
<link rel="stylesheet" href="viewIdeaList.css">
<link rel="stylesheet" href="sidebar.css">
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
<div class="page-wrapper">
    <span class="hamburger-icon" id="hamburger-icon">&#9776;</span>
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-nav-wrapper">
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="editProfile.php"><img src="IMAGES/Navbar/profile.png" alt="Profile"></a></li>
                    <li><a href="mainpage.php"><img src="IMAGES/Navbar/addidea.png" alt="Add Idea"></a></li>
                    <li><a href="viewIdeaList.php"><img src="IMAGES/Navbar/list.png" alt="View Idea List"></a></li>
                    <li><a href="searchIdeas.php"><img src="IMAGES/Navbar/search.png" alt="Search Idea"></a></li>
                </ul>
            </nav>
            <div class="sidebar-bottom">
                <a href="settings.php"><img src="IMAGES/Navbar/settings.png" alt="Settings"></a>
            </div>
        </div>
    </aside>

    <main class="main-content">
        <header class="header">
            <h1 class="page-title">YOUR IDEAS</h1>
            <img src="IMAGES/default-avatar.png" id="mainAvatar" alt="User Avatar" class="user-avatar">
        </header>

        <div class="filter-controls">
            <label for="categorySelect">Category:</label>
            <select id="categorySelect">
                <option value="all">All</option>
                <option value="music">Music</option>
                <option value="work">Work</option>
                <option value="personal">Personal</option>
                <option value="hobby">Hobby</option>
            </select>

            <label for="sortSelect">Sort by:</label>
            <select id="sortSelect">
                <option value="default">Default</option>
                <option value="date">Date</option>
                <option value="az">Title A–Z</option>
                <option value="za">Title Z–A</option>
            </select>
        </div>

        <div id="ideasContainer" class="ideas-container"></div>

        <footer class="footer">
            <p>© 2025 IdeaSpark Inc. All rights reserved.</p>
        </footer>
    </main>
</div>

<script>
const ideasContainer = document.getElementById("ideasContainer");
const categorySelect = document.getElementById("categorySelect");
const sortSelect = document.getElementById("sortSelect");
const hamburger = document.getElementById("hamburger-icon");
const sidebar = document.getElementById("sidebar");
const mainContent = document.querySelector(".main-content");
const mainAvatar = document.getElementById("mainAvatar");

hamburger.addEventListener("click", () => {
    sidebar.classList.toggle("sidebar-active");
    mainContent.classList.toggle("shifted");
});

mainAvatar.src = localStorage.getItem("profileImage") || "IMAGES/default-avatar.png";

document.querySelectorAll(".sidebar-nav a").forEach(link => {
    if (link.getAttribute("href") === window.location.pathname.split("/").pop()) {
        link.parentElement.classList.add("active-link");
    }
});

// Ideas from PHP
let ideas = <?php echo json_encode($ideas); ?>;

function renderIdeas() {
    ideasContainer.innerHTML = "";
    let filtered = [...ideas];

    if (categorySelect.value !== "all") {
        filtered = filtered.filter(i => i.category.toLowerCase() === categorySelect.value.toLowerCase());
    }

    switch (sortSelect.value) {
        case "date": filtered.sort((a,b) => new Date(b.date_created) - new Date(a.date_created)); break;
        case "az": filtered.sort((a,b) => a.title.localeCompare(b.title)); break;
        case "za": filtered.sort((a,b) => b.title.localeCompare(a.title)); break;
    }

    if (!filtered.length) {
        ideasContainer.innerHTML = "<p>No ideas found.</p>";
        return;
    }

    filtered.forEach(idea => {
        const card = document.createElement("div");
        card.className = `idea-card ${idea.pinned ? 'pinned' : ''} ${idea.category.toLowerCase()}-bg`;
        card.innerHTML = `
            <h3 contenteditable="true" class="idea-title">${idea.title}</h3>
            <p contenteditable="true" class="idea-text">${idea.description}</p>
            <p><strong>Category:</strong>
                <select class="idea-category">
                    <option value="music" ${idea.category === 'music' ? 'selected' : ''}>Music</option>
                    <option value="work" ${idea.category === 'work' ? 'selected' : ''}>Work</option>
                    <option value="personal" ${idea.category === 'personal' ? 'selected' : ''}>Personal</option>
                    <option value="hobby" ${idea.category === 'hobby' ? 'selected' : ''}>Hobby</option>
                </select>
            </p>
            <p><strong>Date:</strong> ${idea.date_created}</p>
            <div class="button-group">
                <button class="pin-btn">${idea.pinned ? 'Unpin' : 'Pin'}</button>
                <button class="save-btn">Save</button>
                <button class="delete-btn">Delete</button>
            </div>
        `;

        const [pinBtn, saveBtn, deleteBtn] = card.querySelectorAll("button");

        // Pin/Unpin
        pinBtn.addEventListener("click", () => {
            fetch("", {
                method:"POST",
                headers: {'Content-Type':'application/x-www-form-urlencoded'},
                body:`action=pin&idea_id=${idea.id}`
            }).then(res=>res.json()).then(data=>{
                idea.pinned = data.pinned;
                renderIdeas();
            });
        });

        // Save edits
        saveBtn.addEventListener("click", () => {
            const newTitle = card.querySelector(".idea-title").innerText.trim();
            const newDesc = card.querySelector(".idea-text").innerText.trim();
            const newCategory = card.querySelector(".idea-category").value;
            fetch("", {
                method:"POST",
                headers: {'Content-Type':'application/x-www-form-urlencoded'},
                body:`action=edit&idea_id=${idea.id}&title=${encodeURIComponent(newTitle)}&description=${encodeURIComponent(newDesc)}&category=${encodeURIComponent(newCategory)}`
            }).then(res=>res.json()).then(data=>{
                if(data.updated){
                    idea.title = newTitle;
                    idea.description = newDesc;
                    idea.category = newCategory;
                    renderIdeas();
                }
            });
        });

        // Delete
        deleteBtn.addEventListener("click", () => {
            if(confirm(`Delete idea "${idea.title}"?`)){
                fetch("", {
                    method:"POST",
                    headers: {'Content-Type':'application/x-www-form-urlencoded'},
                    body:`action=delete&idea_id=${idea.id}`
                }).then(res=>res.json()).then(data=>{
                    if(data.deleted){
                        ideas = ideas.filter(i => i.id !== idea.id);
                        renderIdeas();
                    }
                });
            }
        });

        ideasContainer.appendChild(card);
    });
}

categorySelect.addEventListener("change", renderIdeas);
sortSelect.addEventListener("change", renderIdeas);
renderIdeas();
</script>
</body>
</html>
