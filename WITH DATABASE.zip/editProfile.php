<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "ideaspark_db";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$user_id = $_SESSION['user_id'];

// Fetch current user info
$result = $conn->query("SELECT * FROM users WHERE id=$user_id");
$user = $result->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = $conn->real_escape_string($_POST['first_name']);
    $last_name  = $conn->real_escape_string($_POST['last_name']);
    $email      = $conn->real_escape_string($_POST['email']);
    $address    = $conn->real_escape_string($_POST['address']);
    $phone      = $conn->real_escape_string($_POST['contactNumber']);
    $password   = $_POST['password'];

    // PROFILE PHOTO
    $profile_photo_sql = '';
    if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/uploads/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

        $fileTmp = $_FILES['profile_photo']['tmp_name'];
        $fileName = uniqid() . '_' . basename($_FILES['profile_photo']['name']);
        $targetFile = $uploadDir . $fileName;

        if (move_uploaded_file($fileTmp, $targetFile)) {
            $relativePath = "uploads/$fileName";
            $profile_photo_sql = ", profile_photo='$relativePath'";
            $_SESSION['profile_photo'] = $relativePath; // session update
        } else {
            $error = "Failed to upload profile photo.";
        }
    } else {
        // keep existing photo
        if (!empty($user['profile_photo'])) {
            $profile_photo_sql = ", profile_photo='" . $user['profile_photo'] . "'";
        }
    }

    // PASSWORD
    $password_sql = '';
    if (!empty($password)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $password_sql = ", password='$hashedPassword'";
    }

    // EMAIL CHECK
    $check = $conn->query("SELECT * FROM users WHERE email='$email' AND id!=$user_id");
    if ($check->num_rows > 0) {
        $error = "Email already in use!";
    } else {
        $conn->query("UPDATE users SET
            first_name='$first_name',
            last_name='$last_name',
            email='$email',
            address='$address',
            phone='$phone'
            $password_sql
            $profile_photo_sql
            WHERE id=$user_id");

        // update session and reload user
        $_SESSION['first_name'] = $first_name;
        $_SESSION['last_name'] = $last_name;
        $_SESSION['email'] = $email;

        $success = "Profile updated successfully!";
    }

    $result = $conn->query("SELECT * FROM users WHERE id=$user_id");
    $user = $result->fetch_assoc();
}

$conn->close();

$profilePhoto = !empty($user['profile_photo']) ? $user['profile_photo'] : 'IMAGES/default-avatar.png';
?>
